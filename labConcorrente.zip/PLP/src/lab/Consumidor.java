package lab;

public class Consumidor extends Thread{
	
	private int  id;
	private Buffer buffer;
	private int totalConsumir;
	
	public Consumidor(int id, Buffer bufferCompartilhado2, int totalConsumir) {
		this.id = id;
		this.buffer = bufferCompartilhado2;
		this.totalConsumir = totalConsumir;
	}
	
	 
	public void run() {
	    for (int i = 0; i < totalConsumir; i++) {
	         buffer.get(id);
	    }
	    System.out.println("Consumidor #" + id + " concluido!");
	}
	
	

}
