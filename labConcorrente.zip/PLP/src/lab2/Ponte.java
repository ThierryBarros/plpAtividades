package lab2;

public class Ponte extends Thread {
	
    private boolean disponivel;

	public void carro(String carro) {
		String indo = carro;
		String chegando;
		if(indo=="A") {
			chegando = "B";
		}else {
			chegando = "A";
		}
		set(indo,chegando);
		
	}

    public synchronized void set(String indo,String chegando) {
        while (disponivel == true) {
            try {
                System.out.println("Passando carro "+indo+"--->"+chegando);
                wait();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
          
        disponivel = true;
        notifyAll();
    }
 
   

}
