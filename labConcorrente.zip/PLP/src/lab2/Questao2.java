package lab2;

public class Questao2 {
	
	public static void main(String[] args) {
		
		Ponte p = new Ponte();
		p.carro("A");
		p.carro("B");
		p.carro("A");
		}
	
}
